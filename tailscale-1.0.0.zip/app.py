"""Tailscale для PiNAS: установка из официального репозитория, вход, настройки, устройства."""

import asyncio
import ipaddress
import json
import os
import re
import shutil
import socket

import aiohttp
from aiohttp import web

import pinas_sdk as sdk
from pinas_sdk import ApiError
from pinas_sdk.jobs import Jobs

jobs = Jobs()
CORE_PORT = os.environ.get("PINAS_CORE_PORT", "5000")
SYSCTL = "/etc/sysctl.d/99-pinas-tailscale.conf"
KEYRING = "/usr/share/keyrings/tailscale-archive-keyring.gpg"
APT_LIST = "/etc/apt/sources.list.d/tailscale.list"
URL_RE = re.compile(r"https://login\.tailscale\.com/\S+")

settings = sdk.load_json("settings.json", {"exit_node": False, "routes": []})
login = {"url": None, "proc": None}


async def run(*cmd, timeout=30, input_text=None):
    try:
        p = await asyncio.create_subprocess_exec(
            *cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.STDOUT,
            stdin=asyncio.subprocess.PIPE if input_text else asyncio.subprocess.DEVNULL,
        )
    except FileNotFoundError:
        return 127, f"{cmd[0]}: не найдено"
    try:
        out, _ = await asyncio.wait_for(p.communicate(input_text.encode() if input_text else None), timeout)
    except asyncio.TimeoutError:
        p.kill()
        return 124, ""
    return p.returncode, out.decode("utf-8", "replace")


def installed():
    return bool(shutil.which("tailscale"))


def lan_subnet():
    """Подсеть домашней сети, через которую Pi выходит в интернет (для «доступа к домашней сети»)."""
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.connect(("10.255.255.255", 1))
            ip = s.getsockname()[0]
        return str(ipaddress.ip_interface(ip + "/24").network)
    except OSError:
        return None


def peer_json(p):
    return {
        "name": p.get("HostName", ""),
        "dns": (p.get("DNSName") or "").rstrip("."),
        "ips": p.get("TailscaleIPs") or [],
        "os": p.get("OS", ""),
        "online": bool(p.get("Online")),
        "last_seen": p.get("LastSeen"),
        "exit_node": bool(p.get("ExitNode")),
    }


async def api_status(request):
    sdk.require_admin(request)
    install_job = jobs.running("Установка Tailscale")
    if not installed():
        return web.json_response({"installed": False, "job": install_job["id"] if install_job else None})
    _, ver = await run("tailscale", "version")
    code, out = await run("tailscale", "status", "--json")
    try:
        st = json.loads(out) if code in (0, 1) and out.strip().startswith("{") else {}
    except ValueError:
        st = {}
    state = st.get("BackendState") or ("NoState" if code == 127 else "Stopped")
    auth_url = st.get("AuthURL") or login["url"]
    me = peer_json(st.get("Self") or {})
    peers = sorted((peer_json(p) for p in (st.get("Peer") or {}).values()), key=lambda p: (not p["online"], p["name"].lower()))
    _, serve_out = await run("tailscale", "serve", "status", "--json")
    serving = serve_out.strip() not in ("", "{}", "null") and serve_out.strip().startswith("{")
    _, daemon = await run("systemctl", "is-active", "tailscaled")
    return web.json_response(
        {
            "installed": True,
            "version": ver.splitlines()[0] if ver else "",
            "daemon": daemon.strip(),
            "state": state,
            "auth_url": auth_url if state in ("NeedsLogin", "NoState") else None,
            "self": me,
            "tailnet": (st.get("CurrentTailnet") or {}).get("Name", ""),
            "peers": peers,
            "settings": settings,
            "lan_subnet": lan_subnet(),
            "serve": serving,
            "core_port": CORE_PORT,
            "job": install_job["id"] if install_job else None,
        }
    )


# --- установка ---


async def api_install(request):
    sdk.require_admin(request)
    if jobs.running("Установка Tailscale"):
        raise ApiError("Установка уже идёт")

    async def work(job):
        osr = {}
        with open("/etc/os-release", encoding="utf-8") as f:
            for line in f:
                if "=" in line:
                    k, v = line.strip().split("=", 1)
                    osr[k] = v.strip('"')
        distro = "raspbian" if osr.get("ID") == "raspbian" else "debian"
        codename = osr.get("VERSION_CODENAME") or "bookworm"
        base = f"https://pkgs.tailscale.com/stable/{distro}/{codename}"
        jobs.log(job, f"Репозиторий Tailscale: {base}\n")
        async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=60)) as s:
            for url, path in ((base + ".noarmor.gpg", KEYRING), (base + ".tailscale-keyring.list", APT_LIST)):
                async with s.get(url) as r:
                    if r.status != 200:
                        raise RuntimeError(f"{url}: HTTP {r.status} — возможно, {codename} ещё не поддерживается")
                    data = await r.read()
                os.makedirs(os.path.dirname(path), exist_ok=True)
                with open(path, "wb") as f:
                    f.write(data)
                jobs.log(job, f"Сохранено: {path}\n")
        await jobs.exec(job, "apt-get", "update")
        await jobs.exec(job, "apt-get", "install", "-y", "tailscale")
        await jobs.exec(job, "systemctl", "enable", "--now", "tailscaled")
        jobs.log(job, "\nTailscale установлен. Теперь нажмите «Войти».\n")

    return web.json_response({"job": jobs.start("Установка Tailscale", work)["id"]})


async def api_uninstall(request):
    sdk.require_admin(request)

    async def work(job):
        await jobs.exec(job, "tailscale", "logout", check=False)
        await jobs.exec(job, "apt-get", "remove", "-y", "tailscale")
        for p in (APT_LIST, SYSCTL):
            if os.path.exists(p):
                os.remove(p)

    return web.json_response({"job": jobs.start("Удаление Tailscale", work)["id"]})


# --- подключение ---


def set_forwarding(on):
    """Для выходного узла и доступа к домашней сети Pi должен пересылать пакеты."""
    if on:
        with open(SYSCTL, "w", encoding="utf-8") as f:
            f.write("# PiNAS Tailscale\nnet.ipv4.ip_forward = 1\nnet.ipv6.conf.all.forwarding = 1\n")
    elif os.path.exists(SYSCTL):
        os.remove(SYSCTL)


async def ts_up():
    """tailscale up со всеми флагами, которыми управляет PiNAS (--reset — чтобы не спорить со старыми)."""
    if login["proc"] and login["proc"].returncode is None:
        return
    args = ["tailscale", "up", "--reset", f"--hostname={socket.gethostname()}", "--accept-dns=false"]
    if settings.get("exit_node"):
        args.append("--advertise-exit-node")
    if settings.get("routes"):
        args.append("--advertise-routes=" + ",".join(settings["routes"]))
    login["url"] = None
    proc = await asyncio.create_subprocess_exec(*args, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.STDOUT)
    login["proc"] = proc

    async def watch():
        # пока аккаунт не подтверждён, up ждёт и печатает ссылку для входа
        async for line in proc.stdout:
            m = URL_RE.search(line.decode("utf-8", "replace"))
            if m:
                login["url"] = m.group(0)
        await proc.wait()
        login["url"] = None

    asyncio.ensure_future(watch())
    for _ in range(40):  # до 8 с: либо подключились сразу, либо появилась ссылка
        if proc.returncode is not None or login["url"]:
            break
        await asyncio.sleep(0.2)
    if proc.returncode not in (None, 0):
        raise ApiError("tailscale up завершился с ошибкой, смотрите журнал приложения")


async def api_up(request):
    sdk.require_admin(request)
    await ts_up()
    return web.json_response({"ok": True, "auth_url": login["url"]})


async def api_down(request):
    sdk.require_admin(request)
    code, out = await run("tailscale", "down")
    if code != 0:
        raise ApiError(out.strip())
    return web.json_response({"ok": True})


async def api_logout(request):
    sdk.require_admin(request)
    await run("tailscale", "logout", timeout=20)
    return web.json_response({"ok": True})


async def api_settings(request):
    sdk.require_admin(request)
    body = await request.json()
    routes = []
    for r in body.get("routes", []):
        try:
            net = ipaddress.ip_network(str(r).strip(), strict=False)
        except ValueError:
            raise ApiError(f"Подсеть «{r}» указана неверно, пример: 192.168.31.0/24")
        if not net.is_private:
            raise ApiError(f"{net} — не домашняя подсеть")
        routes.append(str(net))
    settings.update(exit_node=bool(body.get("exit_node")), routes=routes)
    sdk.save_json("settings.json", settings)
    set_forwarding(settings["exit_node"] or bool(routes))
    await run("sysctl", "--system")
    flags = [f"--advertise-exit-node={'true' if settings['exit_node'] else 'false'}", "--advertise-routes=" + ",".join(routes)]
    code, out = await run("tailscale", "set", *flags)
    if code != 0:
        raise ApiError(out.strip() or "tailscale set: ошибка")
    return web.json_response({"ok": True})


async def api_serve(request):
    """HTTPS-адрес https://<имя>.<tailnet>.ts.net для PiNAS внутри Tailscale."""
    sdk.require_admin(request)
    if (await request.json()).get("enabled"):
        code, out = await run("tailscale", "serve", "--bg", CORE_PORT, timeout=20)
        m = re.search(r"https://login\.tailscale\.com/\S+", out)
        if m:  # в tailnet ещё не включены HTTPS-сертификаты — Tailscale просит включить по ссылке
            return web.json_response({"ok": False, "enable_url": m.group(0)})
        if code != 0:
            raise ApiError(out.strip()[-300:] or "tailscale serve: ошибка")
    else:
        await run("tailscale", "serve", "reset")
    return web.json_response({"ok": True})


app = sdk.create_app(__file__)
r = app.router
r.add_get("/api/status", api_status)
r.add_get("/api/jobs/{id:\\d+}", jobs.handler)
r.add_post("/api/install", api_install)
r.add_post("/api/uninstall", api_uninstall)
r.add_post("/api/up", api_up)
r.add_post("/api/down", api_down)
r.add_post("/api/logout", api_logout)
r.add_post("/api/settings", api_settings)
r.add_post("/api/serve", api_serve)

if __name__ == "__main__":
    sdk.run(app)
